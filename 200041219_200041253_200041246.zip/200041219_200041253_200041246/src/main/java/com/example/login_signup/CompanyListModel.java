package com.example.login_signup;

public class CompanyListModel {
    String company_name;
    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }


    public CompanyListModel(String company_name) {
        this.company_name = company_name;
    }


}
