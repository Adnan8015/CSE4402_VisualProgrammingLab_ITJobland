//package com.example.login_signup;
//
//public class ApplicantPDFModel {
//}

package com.example.login_signup;

public class ApplicantPDFModel {
    String applicant_name;


}
