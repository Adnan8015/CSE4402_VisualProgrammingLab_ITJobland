package com.example.login_signup;

public class EmployeeJobListModel {
}
